#include <iostream>
#include <fstream>
#include <cctype>
#include <string.h>

using namespace std;

int main(){
    cout << "Please enter the number you would like to get:" << endl;
    int result;
    cin >> result;                          //norimas rezultatas
    int A[]={1, 2, 3, 4, 5, 6, 7, 8, 9};    //pagrindiniai duomenys
    int amount = sizeof(A)/sizeof(A[0]);
    int signs[amount-1];                    //zenklai (tarp skaiciu todel -1)
    int temp[amount];                       //laikinas masyvas, kai bus norima daryti veiksmus tarp skaiciu
    int temp2[amount-1];                    //laikinas masyvas laikyti zenklam, jeigu ju yra;

    //zenklai 0 - nera zenklo, 1 = +, 2 = *
    //!galima butu prideti daugiau norint, tik reiktu salygu zenklam, veiksmam ir rezultatams
    for (int i = 0; i < amount-1; i++){ //
        signs[i]=0; //zenklai ir ju pozicijos

        //taip pat temp2 masyvas padaromas i neutralu, nes jame nesaugomi zenklai dar
        temp2[i]=-1;
    }

    //visi temp elementai padaromi 0 is pradziu, nes nera juose laikomi jokie skaiciai dar
    for (int i = 0; i < amount; i++){
        temp[i]=0;
    }

    while (signs[amount-2] != 3){                   //kol nepraeinami visi variantai daroma...
        int j = 0;
        //suskirstomi visi masyvo skaiciai i "pilnus" skaicius pvz 123+456 tai temp[0]==123, temp[1]=456
        for (int i = 0; i < amount-1; i++){
            if (signs[i] == 0){                     //jei zenklo nera (signs[i] nera 1 arba 2)
                temp[j]=temp[j]*10+A[i];
            }
            else{                                   //jei zenklas buvo
                temp[j]=temp[j]*10+A[i];
                temp2[j]=signs[i];
                j++;
            }
            //jei prieitas paskutinis sk, jis tiesiog pridedamas prie naujos temp, jei amount-1 buvo zenklas, arba pridedamas prie seno
            if (i == amount-2){
                temp[j]=temp[j]*10+A[amount-1];
            }
        }

        int signAmount = j;                                 //issaugomas zenklu kiekis

        //temp2 masyve (zenklu laikinam masyve) ieskoma daugybos zenklu (nes daugybai pirmenybe)
        for (int i = 0; i <= signAmount; i++){
            if (temp2[i] == 2){                             //jei zenklas - daugyba, tada...
                temp[i]=temp[i]*temp[i+1];                  //sudauginami skaiciai
                for (int k = i+1; k <=signAmount+1;k++){    //perstumiami skaiciai per 1 atgal
                    temp[k]=temp[k+1];
                }
                for (int k = i; k <=signAmount; k++){       //perstumiami zenklai per 1 atgal
                    temp2[k]=temp2[k+1];
                }
                j--;                                        //sumazinamas likusiu zenklu kiekis per 1
                i--;                                        //sumazinamas einamo zenklo numeris, nes zenklai buvo perstumti per 1
            }
        }

        signAmount=j;                       //priskiriamas naujas zenklu kiekis (sumazinamas veiksmu skaicius sudeciai)

        for (int i = 0; i <= signAmount; i++){//daroma logiskai tas pats, kas su daugyba, tik ieskoma sudeties si kart
            if (temp2[i] == 1){                             //jei zenklas sudetis, tada...
                temp[i]=temp[i]+temp[i+1];                  //sudedami skaiciai
                for (int k = i+1; k <=signAmount+1;k++){    //perstumiami like skaiciai per 1
                    temp[k]=temp[k+1];
                }
                for (int k = i; k <=signAmount; k++){       //perstumiami visi zenklai per 1
                    temp2[k]=temp2[k+1];
                }
                j--;                                        //sumazinamas likusiu zenklu skaicius
                i--;                                        //sumazinamas einamo zenklo numeris, nes zenklai buvo perstumti per 1
            }
        }

        if (temp[0]==result){                       //jei po daugybos ir sudeties skaicius atitinka norima...
            for (int i = 0; i < amount-1; i++){
                cout << A[i];                       //atspauzdinamas vienas skaicius
                if (signs[i]==1){                   //jei buvo sudetis parasomas + po skaiciaus
                    cout << "+";
                }
                if (signs[i]==2){                   //jei buvo daugyba parasomas * po skaiciaus
                    cout << "*";
                }
            }
            cout << A[amount-1];                    //atspauzdinamas paskutinis skaicius, nes pries tai ciklas vyko kol pasibaige zenklu masyvas
            cout << "=" << result;                  //atspauzdinama = ir rezultatas, kokio noreja vartotojas, nes jau buvo tikrinimo salyga temp[0]== result
            return 0;                               //kadangi veiksmu seka buvo rasta iseinama is programos
        }
        for (int i = 0; i < amount; i++){           //jei veiksmu seka nebuvo rasta istrinamos visos laikinu skaiciu masyvo reiksmes
            temp[i]=0;
        }
        signs[0]++;                                 //pagrindinio zenklu masyvo pirma reiksme padidinama 1, kad butu perrinkti visi zenklai

        for (int i = 0; i < amount-1; i++){         //jei veiksmu seka nebuvo rasta keiciamos laikino masyvo reiksmes
            temp2[i]=-1;                            //-1 - isivaizduojam kad nera jokio zenklo, gali buti bet kas isskyrus 1 ir 2
            if (signs[i]>2){                        //jei zenklas buvo + ir * ir patapo 3...
                if (i < amount-2){                  //ir tai ne paskutinis zenklas...
                   signs[i+1]++;                    //sekantis zenklas patampa 1 didesnis, o...
                   signs[i]=0;                      //sis zenklas patampa niekuo
                }
                else{                               //jei visgi tai buvo paskutinis zenklas
                    cout << "Such result cannot be got!!!" << endl;
                    return 0;                       //reiskia nera galima gauti norimos reiksmes, tad tiesiog tai parasoma ir iseinama is programos
                }
            }
        }
    }
}
