//Mindaugas Burvys PI17B
//blaide333@yahoo.com mindaugas.burvys@stud.viko.lt

#include <iostream>
#include <fstream>
#include <string.h>
#include <cctype>
#include <time.h>
#include <stdlib.h>

using namespace std;

int main()
{
    ifstream file ("figuros.txt");  //atidaromas failas skaitymui
    if (!file){
        cout << "Error while opening file" << endl;
        return 1;
    }
    ofstream output ("output.html");
    string temp;
    int shapeCounter[7];    //7figuros: Polyline, Polygon, Line, Elipse, Circle, Rectangle ir jei vardas nebuvo atpazintas

    for (int i = 0; i < 7; i++){//figuru kiekis padaromas 0, nes dar nebuvo nuskaityta nei viena figura
        shapeCounter[i]=0;
    }

    output << "<!DOCTYPE html>" << endl << "<html>" << endl << "<body>" << endl; //pradedamas rasyti html failas

    //suskaiciuojama kiek kokiu figuru yra faile
    while(file >> temp){//kol yra figuru faile...
        if ( temp[temp.size()-1] == ','){ //jei kintamasis pasibaige ',' , jis istrinamas is kintamojo, nes nera reikalingas
                temp.resize(temp.size() - 1);
        }

        //skaiciuojama kur kokia figura buvo, jei tai vienam lange kelios figuros, jos skaiciuojamos, kaip kelios
        if (temp == "Polyline"){
            shapeCounter[0]++;
        }
        else{
            if(temp == "Polygon"){
                shapeCounter[1]++;
            }
            else{
                if(temp == "Line"){
                    shapeCounter[2]++;
                }
                else{
                    if(temp == "Ellipse"){
                        shapeCounter[3]++;
                    }
                    else{
                        if(temp == "Circle"){
                            shapeCounter[4]++;
                        }
                        else{
                            if(temp == "Rectangle"){
                                shapeCounter[5]++;
                            }
                            else{
                                shapeCounter[6]++;
                            }
                        }
                    }
                }
            }
        }
    }
    //tam kad lentele turetu krastines
    output << "<style>" << endl << "table, th, td {" << endl << "border: 1px solid black;" << endl << "border-collapse: collapse;" << endl << "}" << "</style>" << endl << endl;

    output << endl <<"If a shape in file contained multiple shapes (ex. Line Line Line) these are counted as separate shapes (ex. 3 Lines). However they aren't drawn separately." << endl<< endl;
    output << "<table style=\"width:100%\">" << endl;       //pradedama rasyti lentele

    //figuru pavadinimai
    output << "<tr>" << endl;
    output << "<th>Polyline</th>" << endl;
    output << "<th>Polygon</th>" << endl;
    output << "<th>Line</th>" << endl;
    output << "<th>Ellipse</th>" << endl;
    output << "<th>Circle</th>" << endl;
    output << "<th>Rectangle</th>" << endl;
    output << "<th>Other figures</th>" << endl;
    output << "</tr>" << endl;

    //figuru kiekiai
    output << "<tr>" << endl;
    for (int i = 0; i < 7; i++){
        output << "<th>" << shapeCounter[i] << "</th>" << endl;
    }
    output << "</tr>" << endl;

    output << "</table>" << endl << endl;                           //baigiama rasyti lentele

    file.clear();                  //Griztama i failo pradzia, pasiruosiama piesti figuras
    file.seekg(0, ios::beg);

    srand (time(NULL)); //parenkamas random seed'as pagal laika

    while (file >> temp){//pradedami paisyti objektai, tam kad jie butu pakankamai mazi, ju visu dydziai ne didesni negu 100x100
        if (temp[temp.size()-1] == ','){ //jei tai tik "1 zodzio figura"
            temp.resize(temp.size() - 1); //atimamas kablelis
            output << temp <<":"; //parasoma kokia figura
        //ir pagal tai, kokia tai figura ja atvaizduojama SVG objektu
            if (temp == "Polyline"){ //polyline pavaizdaimas SVG objektu
                output << "<svg width=\"100\" height=\"100\">" << endl;
                output << "<polyline points=\"";
                for (int i = 0; i < rand()%10+3; i++){
                    output << rand()%100 << "," << rand()%100 << " ";
                }
                output << "\"" << endl << "style=\"fill:none;";
                output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                output << "</svg>" << endl;
            }
            else{   //polygon pavaizdaimas SVG objektu
                if(temp == "Polygon"){
                    output << "<svg width=\"100\" height=\"100\">" << endl;
                    output << "<polygon points=\"";
                    for (int i = 0; i < rand()%5+3; i++){
                        output << rand()%100 << "," << rand()%100 << " ";
                    }
                    output << "\"" << endl << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                    output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                    output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                    output << "</svg>" << endl;
                }
                else{
                    if(temp == "Line"){ //line pavaizdaimas SVG objektu
                        output << "<svg width=\"100\" height=\"100\">" << endl;
                        output << "<line x1=\"" <<rand()%100 << "\" y1=\"" << rand()%100 << "\" x2=\"" << rand()%100 << "\" y2=\"" << rand()%100 <<"\" ";
                        output <<"style=\"stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                        output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                        output << "</svg>" << endl;
                    }
                    else{
                        if(temp == "Ellipse"){ //ellipse pavaizdaimas SVG objektu
                            output << "<svg width=\"100\" height=\"100\">" << endl;
                            output << "<ellipse cx=\"" <<rand()%100 << "\" cy=\"" << rand()%100 << "\" rx=\"" << rand()%100 << "\" ry=\"" << rand()%100 <<"\" ";
                            output << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                            output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                            output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                            output << "</svg>" << endl;
                        }
                        else{
                            if(temp == "Circle"){ //circle pavaizdaimas SVG objektu
                                output << "<svg width=\"100\" height=\"100\">" << endl;
                                output << "<circle cx=\"" <<rand()%100 << "\" cy=\"" << rand()%100 << "\" r=\"" << rand()%100 << "\" ";
                                output << "stroke=rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256 << ") ";
                                output << "stroke-width=" << rand()%10+1 << "\" ";
                                output << "fill=rgb(" << rand()%256 << "," << rand()%256 << "," << rand()%256 << ") />" << endl;
                                output << "</svg>" << endl;
                            }
                            else{
                                if(temp == "Rectangle"){ //rectangle pavaizdaimas SVG objektu
                                    output << "<svg width=\"100\" height=\"100\">" << endl;
                                    output << "<rect width=\"" << rand()%99+1 << "\" height=\"" << rand()%99+1 << "\" ";
                                    output << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                                    output << "stroke-width:" << rand()%10+1 << "\";";
                                    output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ")\" />";
                                    output << "</svg>" << endl;
                                }
                            }
                        }
                    }
                }
            }
        }
        else{                                   //jei zodis neturejo kablelios
            string temp2[100];
            int i =0;
            temp2[i] = temp;
            i++;
            while (temp[temp.size()-1] != ','){ //surasomi visi zodziai i masyva
                file >> temp;
                temp2[i] = temp;
                i++;
            }

            if (temp2[i-1][temp2[i-1].size()-1] == ','){ //is paskutinio zodzio atimamas kablelis
                temp2[i-1].resize(temp2[i-1].size() - 1);
            }

            for (int j = 0; j <i; j++){ //israsoma visu laukelyje pasirodanciu figuru pavadinimai
                output << temp2[j] << " ";
            }
            output << ":" << endl;

            //ir visos figuros po viena atvaizduojamos 1 laukelyje, identiskai tarsi butu tik 1 figura, tik ji neturi savo laukelio, o naudoja bendra
            output << "<svg width=\"100\" height=\"100\">" << endl;
            for (int j =0; j <= i; j++){
                if (temp2[j] == "Polyline"){
                    output << "<polyline points=\"";
                    for (int i = 0; i < rand()%10+3; i++){
                        output << rand()%100 << "," << rand()%100 << " ";
                    }
                    output << "\"" << endl << "style=\"fill:none;";
                    output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                    output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                }
                else{
                    if(temp2[j] == "Polygon"){
                        output << "<polygon points=\"";
                        for (int i = 0; i < rand()%5+3; i++){
                            output << rand()%100 << "," << rand()%100 << " ";
                        }
                        output << "\"" << endl << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                        output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                        output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                    }
                    else{
                        if(temp2[j] == "Line"){
                            output << "<line x1=\"" <<rand()%100 << "\" y1=\"" << rand()%100 << "\" x2=\"" << rand()%100 << "\" y2=\"" << rand()%100 <<"\" ";
                            output <<"style=\"stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                            output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                        }
                        else{
                            if(temp2[j] == "Ellipse"){
                                output << "<ellipse cx=\"" <<rand()%100 << "\" cy=\"" << rand()%100 << "\" rx=\"" << rand()%100 << "\" ry=\"" << rand()%100 <<"\" ";
                                output << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                                output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                                output << "stroke-width:" << rand()%10+1 << "\" />" << endl;
                            }
                            else{
                                if(temp2[j] == "Circle"){
                                    output << "<circle cx=\"" <<rand()%100 << "\" cy=\"" << rand()%100 << "\" r=\"" << rand()%100 << "\" ";
                                    output << "stroke=rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256 << ") ";
                                    output << "stroke-width=" << rand()%10+1 << "\" ";
                                    output << "fill=rgb(" << rand()%256 << "," << rand()%256 << "," << rand()%256 << ") />" << endl;
                                }
                                else{
                                    if(temp2[j] == "Rectangle"){
                                        output << "<rect width=\"" << rand()%99+1 << "\" height=\"" << rand()%99+1 << "\" ";
                                        output << "style=\"fill:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ");";
                                        output << "stroke-width:" << rand()%10+1 << "\";";
                                        output << "stroke:rgb(" <<rand()%256 <<","<< rand()%256 <<","<< rand()%256<< ")\" />";
                                    }
                                }
                            }
                        }
                    }
                }
            }
            output << "</svg>" << endl;

        }
    }

    output << "</body>" << endl << "</html>"; //paigiamas rasyti html failas

    //uzdaromi failai
    file.close();
    output.close();
    system (".\\output.html"); //atidaromas html failas, kuris ka tik buvo sukurtas
}
