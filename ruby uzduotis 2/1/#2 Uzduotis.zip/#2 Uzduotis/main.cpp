//Mindaugas Burvys PI17B
//blaide333@yahoo.com mindaugas.burvys@stud.viko.lt
//u�duotis skirta rasti, kokio duomenu tipo yra duomenys faile ir juos atspauzdinti

#include <iostream>
#include <fstream>
#include <string.h>
#include <cctype>

using namespace std;

int main()
{
    //atidaromas failas rasymui
    ifstream file ("1500000 Sales Records.csv");
    //jei failas neegzistuoja iskarto klaida
    if (!file){
        cout << "Error while opening file" << endl;
        return 1;
    }
    string temp;
    //atidaromas failass rezultatams
    ofstream file2 ("rezultatai.txt");

    cout << "Working..." << endl;
    //kol neprieinama failo pabaiga...
    while (!file.eof()){
        //gaunama eilute
        getline(file, temp);
        int i = 0;
        //kol neprieinama eilutes pabaiga
        while (i < temp.size()){
            //ieskomas kablelis
            if (temp[i] == ','){
                i++;
            }
            //ieskomas simbolis ir po jo einantis kablelis arba eilutes pabaiga
            if (!isdigit(temp[i]) && temp[i+1] =='\0' || !isdigit(temp[i]) && temp[i+1] == ','){
            file2 << "char ";
                i++;
            }
            else{
                //jei tai simbolis, bet nesibaigia ',' arba '\0'
                if (!isdigit(temp[i])){
                    //einama kol pasibaigia zodis
                    while (temp[i] != ','){
                        i++;
                    }
                    file2 << "string ";
                }
                else{
                    //jei tai skaicius
                    if(isdigit(temp[i])){
                        //tam kad rasti ar tai float, ar data ar kitoks tipas
                        int counter = 0;
                        //einama kol randamas skaiciaus galas
                        while (isdigit(temp[i])){
                            i++;
                            //jei tai simbolis, bet ne ',', reiskia tai simbolis, kad atskirti data fragmentus arba double dalis
                            if (!isdigit(temp[i]) && temp[i] != ',' && i < temp.size()){
                                counter++;
                                i++;
                            }
                        }
                        //tikrinama, kiek identifikatoriu rasta
                        if (counter == 0){
                            file2 << "int ";
                        }
                        else{
                            if (counter == 1){
                                file2 << "float ";
                            }
                            else{
                                if (counter == 2){
                                    file2 << "data ";
                                }
                                else {
                                    file2 << "unknown_type ";
                                }
                            }
                        }
                    }
                }
            }
        }
        file2 << endl;
    }
    file.close();
    file2.close();
    cout << "\nWriting to file rezultatai.txt done";
}
