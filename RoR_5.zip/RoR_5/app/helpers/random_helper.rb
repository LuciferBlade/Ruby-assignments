module RandomHelper
end
