Rails.application.routes.draw do
  get 'home/index'

  root 'home#index'
  get 'randomD', to: 'random#random_date'
  get 'randomI', to: 'random#random_image'
  get 'randomN', to: 'random#random_number'
end
