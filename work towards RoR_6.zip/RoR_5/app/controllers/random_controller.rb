class RandomController < ApplicationController
  before_action :date_gen, only: [:random_date]
  before_action :url_selector, only: [:random_image]

  def random_number
    @random_num = Random.rand(1_000_000)
  end

  def random_image
    @random_img = url_selector
  end

  def random_date
    @random_d = date_gen
  end

  private

  def date_gen(from = 0.0, to = Time.now)
    @random_d = Time.at(from + rand * (to.to_f - from.to_f))
  end

  def url_selector
    temp = ['https://img.buzzfeed.com/buzzfeed-static/static/2016-08/17/18/campaign_images/buzzfeed-prod-fastlane02/18-cats-who-are-just-as-surprised-as-you-are-2-22294-1471473397-0_dblbig.jpg',
            'https://media.wired.com/photos/5cdefb92b86e041493d389df/master/pass/Culture-Grumpy-Cat-487386121.jpg',
            'https://i.redd.it/n2uz800tb6811.jpg',
            'https://i.redd.it/0kygsba48fi01.jpg',
            'https://images.homedepot-static.com/productImages/ee598453-40b1-4e3e-9f32-d9e6ec144a7c/svn/breck-s-flower-bulbs-05150-64_1000.jpg',
            'https://i.pinimg.com/originals/38/8e/0b/388e0bef8b1ceddc99dbf9f6b0e7f2b6.jpg',
            'https://secure.i.telegraph.co.uk/multimedia/archive/03188/maru_the_cat__3188629b.jpg',
            'https://www.pinclipart.com/picdir/middle/334-3348875_report-abuse-kawaii-cute-anime-cat-clipart.png',
            'http://4.bp.blogspot.com/-9NAm22eDEto/U-DHXUfesWI/AAAAAAAACKE/0TLJfx30CFs/s1600/Pusheen-The-Cat-ASCII-Art.jpg',
            'https://miro.medium.com/max/4725/0*n-2bW82Z6m6U2bij.jpeg']
    temp[rand(10)]
  end
end
