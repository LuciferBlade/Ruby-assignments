require 'test_helper'

class Concerns::RandomControllerTest < ActionDispatch::IntegrationTest
  test "should get random_number" do
    get concerns_random_random_number_url
    assert_response :success
  end

  test "should get random_image" do
    get concerns_random_random_image_url
    assert_response :success
  end

  test "should get random_date" do
    get concerns_random_random_date_url
    assert_response :success
  end

end
