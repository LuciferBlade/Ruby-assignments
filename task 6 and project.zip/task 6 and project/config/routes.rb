Rails.application.routes.draw do
  get 'home/index'

  root 'home#index'
  get '/' => 'home#index'
  get 'randomD', to: 'random#random_date'
  get 'randomI', to: 'random#random_image'
  get 'randomN', to: 'random#random_number'
  # project and task 6 routes

  # item view and add
  get 'itemV', to: 'items#items_view'
  get 'itemA', to: 'items#items_add'
  post 'itemAdd', to: 'items#create'
  delete 'itemDel', to: 'items#delete'
  get 'itemEdit', to: 'items#items_edit'
  put 'itemUpdate', to: 'items#update'

  # login, registration and logout
  get 'login', to: 'users#index'
  get 'register', to: 'users#registration'
  post 'usersReg', to: 'users#create'
  post 'usersLog', to: 'sessions#create'
  delete 'logout', to: 'sessions#destroy'
  get 'logout', to: 'sessions#destroy'
  get 'profile', to: 'users#profile'
end
