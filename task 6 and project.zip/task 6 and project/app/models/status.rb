# frozen_string_literal: true

class Status < ActiveRecord::Base
  has_many :item
end
