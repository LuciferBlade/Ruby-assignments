# frozen_string_literal: true

class Item < ActiveRecord::Base

  validates :name, presence: true
  validates :status_id, presence: true
  validates :location, presence: true
end
