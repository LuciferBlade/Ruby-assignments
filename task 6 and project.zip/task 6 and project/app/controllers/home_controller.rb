class HomeController < ApplicationController

  def index
    @image = 'https://upload.wikimedia.org/wikipedia/commons/e/ec/RandomBitmap.png'
  end
end
