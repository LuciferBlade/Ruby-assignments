# frozen_string_literal: true

class ItemsController < ApplicationController
  protect_from_forgery with: :null_session, prepend: true

  def items_view
    @items = Item.all
  end

  def items_edit
    @item = Item.find(params[:id])
    render 'items_edit'
  end

  def update
    @item = Item.find(params[:temp])
    if @item.update(item_params)
      flash[:success] = "Saved!"
      redirect_to '/itemV'
    else
      redirect_to '/itemEdit'
    end
  end

  def create
    item = Item.new(item_params)
    if item.save
      redirect_to '/itemV'
    else
      flash[:item_add_errors] = item.errors.full_messages
      redirect_to '/itemA'
    end
  end

  def delete
    @item = Item.find(params[:temp])
    @item.destroy
    redirect_to '/itemV'
  end

  def item_params
    params.require(:item).permit(:name, :value, :date, :status_id, :location)
  end
end
